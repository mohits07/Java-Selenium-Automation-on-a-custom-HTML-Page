package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Login;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinition2 {

	private WebDriver driver;
	private Login login;

	@Before // cucumber package before
	public void init() {
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		driver = new ChromeDriver(); // instantiate driver

	}

	@After
	public void destroy() {
		driver.quit();
	}

	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String url = "C:\\Users\\msomaiya\\Spring\\HelloBDD\\html\\login.html";
		driver.get(url);
		login = new Login();
		PageFactory.initElements(driver, login);
	}

	@When("^USer enters username$")
	public void user_enters_username() throws Throwable {

		login.setUsername("abc");
	}

	@Then("^Validate username$")
	public void validate_username() throws Throwable {
		login.clickLogin();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enter password$")
	public void user_enter_password() throws Throwable {
		login.setUsername("abc");
		login.setPassword("123");
	}

	@Then("^validate password$")
	public void validate_password() throws Throwable {
		login.clickLogin();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^when submit form$")
	public void when_submit_form() throws Throwable {
		login.setUsername("abcd");
		login.setPassword("1234");
	}

	@Then("^Show successful alert$")
	public void show_successful_alert() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		login.clickLogin();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

}
