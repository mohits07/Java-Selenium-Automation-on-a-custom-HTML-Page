/*package com.cg.step;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinition {

	private WebDriver driver;

	@Before // cucumber package before
	public void init() {
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		driver = new ChromeDriver(); // instantiate driver

	}

	@After
	public void destroy() {
		driver.quit();
	}

	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String url = "C:\\Users\\msomaiya\\Spring\\HelloBDD\\html\\login.html";
		driver.get(url);
	}

	@When("^USer enters username$")
	public void user_enters_username() throws Throwable {

		WebElement element = driver.findElement(By.id("username"));
		element.sendKeys("abc");
	}

	@Then("^Validate username$")
	public void validate_username() throws Throwable {
		WebElement login = driver.findElement(By.id("login"));
		login.click();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enter password$")
	public void user_enter_password() throws Throwable {
		WebElement pwd = driver.findElement(By.id("password"));
		pwd.sendKeys("123");
	}

	@Then("^validate password$")
	public void validate_password() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		// WebElement pwd = driver.findElement(By.id("pasword"));
		WebElement login = driver.findElement(By.id("login"));
		login.click();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^when submit form$")
	public void when_submit_form() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@Then("^Show successful alert$")
	public void show_successful_alert() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		WebElement login = driver.findElement(By.id("login"));
		login.click();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

}
*/