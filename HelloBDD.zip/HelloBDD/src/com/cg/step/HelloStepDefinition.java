package com.cg.step;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HelloStepDefinition {

	@Before
	public void init() {
		System.out.println("this will wxecute before eachstep");
	}

	@After
	public void destroy() {
		System.out.println("Scenario test ends");
	}

	@Given("^Attended training$")
	public void attendedTraining() throws Throwable {
		System.out.println("attended training");
	}

	@When("^Clear L(\\d+)$")
	public void clearL(int arg1) throws Throwable {
		System.out.println("clared L1");
	}

	@Then("^Become Employee$")
	public void becomeEmployee() throws Throwable {
		System.out.println("i am a  slave");
	}

	@Given("^hello given step$")
	public void helloGivenStep() throws Throwable {
		System.out.println("Syaing hello to given step");
	}

	@When("^Hello when step$")
	public void helloWhenStep() throws Throwable {
		System.out.println("Saying hello to when step");
	}

	@Then("^Hello then step$")
	public void Hello_Then_Step() throws Throwable {
		System.out.println("saying hello to then step");
	}

	@Given("^bye given step$")
	public void byeGivenStep() throws Throwable {
		System.out.println("Syaing bye to given step");
	}

	@When("^bye when step$")
	public void byeWhenStep() throws Throwable {
		System.out.println("Saying bye to when step");
	}

	@Then("^bye then step$")
	public void byeThenStep() throws Throwable {
		System.out.println("saying bye to then step");
	}
}
