package com.capgemini;

import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavaScriptTestExample {

	WebDriver driver;// ref variable

	@Before
	public void setup() {

		System.out.println("getting resources");

		System.setProperty("webdriver.chrome.driver",
				"mydriver\\chromedriver.exe");
		driver = new ChromeDriver();// web driver object is created and refering
									// to Chrome browser
		driver.get("https://demo.opencart.com/");
		driver.manage().window().maximize();

	}

	
	@org.junit.Test
	public void login() {

		System.out.println("Login test");

	}

	@org.junit.Test
	public void testMouseOperation() {

		System.out.println("sample test case");

		JavascriptExecutor scriptExecutor = (JavascriptExecutor) driver;

		scriptExecutor.executeScript("alert('welcome to selenium world!!!')");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Alert alert = driver.switchTo().alert();

		String alertMessage = alert.getText();
		alert.accept();

		if (alertMessage.equals("welcome to selenium world!!!")) {

			System.out.println("Match found");
		} else {

			System.out.println("Match not found");

		}
try {
	Thread.sleep(5000);
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
		scriptExecutor.executeScript("confirm('Do you want to continue')");

		alert = driver.switchTo().alert();
		alert.dismiss();

	}

	@After
	public void releaseResource() {

		System.out.println("Resources will be realsed here");

	}

}
