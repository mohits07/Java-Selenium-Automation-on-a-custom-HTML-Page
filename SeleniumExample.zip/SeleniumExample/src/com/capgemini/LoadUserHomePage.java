package com.capgemini;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoadUserHomePage {

	WebDriver driver;

	@Before
	public void getResource() throws InterruptedException {

		System.setProperty("webdriver.chrome.driver",
				"mydriver\\chromedriver.exe");
		driver = new ChromeDriver();

	}

	@Test
	public void load() {

		driver.get("file:///C:/Users/msomaiya/Desktop/Module 4/Demos/SeleniumExample/Demo.html");
		System.out.println("page tiftle" + driver.getTitle());

		// WebElement textElement=driver.findElement(By.id("uid"));

		WebElement element = driver.findElement(By.name("username"));
		element.sendKeys("populated value");

		// WebElement element=driver.findElement(By.cssSelector("html>body>p"));
		// System.out.println("Element Name is"+element.getTagName()+"element text is"+element.getText());

		WebElement headingElement = driver.findElement(By.tagName("h1"));

		String name = headingElement.getTagName();

		String text = headingElement.getText();

		System.out.println("element is\t" + name);
		System.out.println("Text is \t" + text);

		try {

			Thread.sleep(10000);

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@After
	public void releaseResource() {

		driver.close();

	}

}
