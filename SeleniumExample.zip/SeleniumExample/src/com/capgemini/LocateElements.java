package com.capgemini;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

/*package com.capgemini;

import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateElements {

	CaloriePage caloriePage;

	WebDriver driver;

	@Before
	public void setup() {

		System.setProperty("webdriver.chrome.driver",
				"mydriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://www.calculator.net/bmi-calculator.html");
		driver.manage().window().maximize();

		caloriePage = new CaloriePage(driver);

	}

	@org.junit.Test
	public void locate() {

		caloriePage.caloriesEntries();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@After
	public void relaseResources() {

		if (driver != null) {

			driver.quit();

		}

	}

}*/

public class  LocateElements{
	public static void main(String[] args) {
		WebDriver driver = new FirefoxDriver();
		
		driver.get("https://www.google.com/");
		
		WebElement element = driver.findElement(By.name("q"));
		
		element.sendKeys("cheese");
		
		element.submit();
		
		System.out.println("page tiltel is " +driver.getTitle());
		driver.quit();
	}

	
}

